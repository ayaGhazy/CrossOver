package com.crossover.e2e;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import junit.framework.TestCase;
import login.LoginEmail;
import receive.receiveEmail;
import send.SendEmail;
import utilites.Global;

import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


public class GMailTest extends TestCase {
    private WebDriver driver;
    private Properties properties = new Properties();

    public void setUp() throws Exception {
        properties.load(new FileReader(new File("src/test/resources/test.properties")));
        //Dont Change below line. Set this value in test.properties file incase you need to change it..
      //  System.setProperty("webdriver.chrome.driver",properties.getProperty("webdriver.chrome.driver") );
        driver = Global.getDriver();
        File f = new File("src/test/resources/Test Report.txt");
        if(f.exists()){
        	f.delete();
        	try {
        		f.createNewFile();
        	} catch (IOException e) {
        		e.printStackTrace();
        	}
        }
    }

    public void tearDown() throws Exception {
       driver.quit();
    }

    /*
     * Please focus on completing the task
     * 
     */
    @Test
    public void testSendEmail() throws Exception {
    	try {
    		 Global.getWriter().append("-----------------"+"\n");
    	 Global.getWriter().append("Start Execution: " +"\n");
		 Global.getWriter().append("-----------------"+"\n");
    	 Global.getWriter().append("Steps " +"\n");
		 Global.getWriter().append("-----------------"+"\n");

        driver.get(properties.getProperty("URL"));
   	 Global.getWriter().append("1- Login to Gmail" +"\n");
       LoginEmail.loginEmailData(properties.getProperty("username"), properties.getProperty("password"));
      SendEmail.sendEmailContent(properties.getProperty("username"), properties.getProperty("email.subject"), properties.getProperty("email.body"));
       receiveEmail.receiveChooseEmail(properties.getProperty("email.subject"));
    receiveEmail.verifyEmailContent(properties.getProperty("email.subject"), properties.getProperty("email.body"));
	 Global.getWriter().append("-----------------"+"\n");

    Global.getWriter().append("Results : \n 1 Test case Pass User can send and Receive Email" +"\n");
	 Global.getWriter().append("-----------------"+"\n");

    Global.getWriter().close();
    	}
    	catch(Exception e)
    	{
   		 Global.getWriter().append("-----------------"+"\n");

       	 Global.getWriter().append("Results: \n 1 Test case fail With Error :" +"\n");
		 Global.getWriter().append("-----------------"+"\n");

       	 Global.getWriter().append(e.getMessage() +"\n");
       	Global.getWriter().close();
       	 throw e;

    	}
    // WebElement userElement = driver.findElement(By.id("identifierId"));
       // userElement.sendKeys(properties.getProperty("username"));

       // driver.findElement(By.id("identifierNext")).click();
//
      //  Thread.sleep(1000);

      //  WebElement passwordElement = driver.findElement(By.name("password"));
      //  passwordElement.sendKeys(properties.getProperty("password"));
       // driver.findElement(By.id("passwordNext")).click();

       // Thread.sleep(1000);

//        WebElement composeElement = driver.findElement(By.xpath("//*[@role='button' and (.)='COMPSE']"));
//        composeElement.click();
//
//        driver.findElement(By.name("to")).clear();
//        driver.findElement(By.name("to")).sendKeys(String.format("%s@gmail.com", properties.getProperty("username")));
//        driver.findElement(By.xpath("//*[@role='button' and text()='Send']")).click();
//        
//        // emailSubject and emailbody to be used in this unit test.
//        String emailSubject = properties.getProperty("email.subject");
//        String emailBody = properties.getProperty("email.body"); 
//        
    }
}
