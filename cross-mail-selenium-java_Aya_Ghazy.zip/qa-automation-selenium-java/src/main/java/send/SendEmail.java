 package send;

import java.io.IOException;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilites.Global;

public class SendEmail {
	 public static void sendEmailContent(String email_to, String email_subject, String email_body) throws Exception
     {

         clickComposeButton();
         emailContent(email_to,email_subject,email_body);
    	 Global.getWriter().append("4- User Send Email with email Subject: " +email_subject +" and Body "+email_body+"\n");

     }
     private static void clickComposeButton()
{
    	 WebElement myDynamicElement = (new WebDriverWait(Global.getDriver(), 10))
    			  .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'Compose')]")));

   utilites.SetProperites.click("//div[contains(text(),'Compose')]", "xpath");

}
private static  void emailContent(String email_to,String email_subject,String email_body) throws Exception
     {

        
         Thread.sleep(3000);
         Actions builder = new Actions(Global.getDriver());
         builder.moveToElement(Global.getDriver().findElement(By.name("to"))).sendKeys(email_to).build().perform();
         builder.moveToElement(Global.getDriver().findElement(By.name("to"))).sendKeys(Keys.TAB);
         Thread.sleep(200);
         builder.moveToElement(Global.getDriver().findElement(By.name("subjectbox"))).click().sendKeys(email_subject).build().perform();
         builder.moveToElement(Global.getDriver().findElement(By.name("subjectbox"))).sendKeys(Keys.TAB).sendKeys(email_body).build().perform();
         Thread.sleep(200);
         utilites.SetProperites.click("//*[@data-tooltip='More options']","xpath");
         builder.moveToElement(Global.getDriver().findElement(By.xpath("//div[@role='menu' and @class='J-M Gj jQjAxd']")))
         .moveToElement(
                 Global.getDriver().findElement(By.xpath("//div[@role='menu' and @class='J-M Gj jQjAxd']//*[text()='Label']"))).click().build().perform();
         Thread.sleep(200);

         builder.moveToElement(
                 Global.getDriver().findElement(By.xpath("//*[@class='J-M agd jQjAxd aX1']//*[@title='Unstarred']"))).click()
                 .build().perform();
                 Thread.sleep(200);
                 
         builder.moveToElement(
         Global.getDriver().findElement(By.xpath("//div/div[@title='Social']"))).click()
         .build().perform();
         Thread.sleep(200);

      
        Thread.sleep(1000);
         utilites.SetProperites.click("//div[contains(text(),'Send') and @role='button']", "xpath");

     }

     
     private static void sendEmailButton()
     {
         utilites.SetProperites.click("//div[contains(text(),'Send') and @role='button']", "xpath");
         
     }
   }
   


