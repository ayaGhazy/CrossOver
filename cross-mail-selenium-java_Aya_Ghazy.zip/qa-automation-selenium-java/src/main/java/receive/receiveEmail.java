package receive;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilites.Global;

public class receiveEmail {

	 public static void receiveChooseEmail(String emailSubject ) throws Exception
     {
         searchEmail(emailSubject);
         chooseFirstElement(emailSubject);

     }

   public static void verifyEmailContent(String emailSubject ,String emailBody )
   {
	   utilites.SetProperites.waitElementPresent("//h2[@class='hP']", "xpath");
	  // System.out.print(utilites.SetProperites.getText("//h2[@class='hP']", "xpath"));
	 //  System.out.print(emailSubject);
	  // System.out.print(emailSubject .equals(utilites.SetProperites.getText("//h2[@class='hP']", "xpath")));
	   assertEquals("Subject is not correct", emailSubject .equals(utilites.SetProperites.getText("//h2[@class='hP']", "xpath")),true);
	   assertEquals( "Body is not correct",emailBody.equals(utilites.SetProperites.getText("//div[@dir='ltr' and contains (text(),'body')]", "xpath")),true);
  	 Global.getWriter().append("5- User Receive Correct Email" +"\n");

   }
   
   
     private static void searchEmail(String email_subject)
     {
         WebElement myDynamicElement = (new WebDriverWait(Global.getDriver(), 10))
      			  .until(ExpectedConditions.presenceOfElementLocated(By.name("q")));

         utilites.SetProperites.enterText("q", email_subject, "name");
         utilites.SetProperites.sendKeys("q", Keys.ENTER, "name");
      //   utilites.SetProperites.click("//*[@name='q']/span", "xpath"); 

     }
     private static void chooseFirstElement(String emailSubject)
     {
//    	    List<WebElement>	elements=  utilites.SetProperites.findElements("//div[@role='main']//table[@class='F cf zt']//tr//*[@title='Not starred']", "xpath");
//    	    utilites.SetProperites.sleep(200);
//try {
//    	 WebElement myDynamicElement = (new WebDriverWait(Global.getDriver(), 10))
//     			  .until(ExpectedConditions.visibilityOf(elements.get(0)));;
//}
//catch(IndexOutOfBoundsException e)
//{
//	 utilites.SetProperites.sleep(1000);}
//
//         utilites.SetProperites.click(elements.get(0));
//         try {  elements=  utilites.SetProperites.findElements("//div[@role='main']//table[@class='F cf zt']//tr//*[@title='Starred']", "xpath");
//      
//         new WebDriverWait(Global.getDriver(), 10)
//    			  .until(ExpectedConditions.visibilityOf(elements.get(0)));
//        }catch(IndexOutOfBoundsException e)
//        {
//          	 utilites.SetProperites.sleep(1000);}
 	    List<WebElement> elements=  utilites.SetProperites.findElements("//div[@role='main']//table[@class='F cf zt']//tr//span/*[text()='"+emailSubject+"']", "xpath");
         utilites.SetProperites.click(elements.get(0));    
            
     }
   }
