package login;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utilites.Global;

public class LoginEmail {

	  public static void loginEmailData(String email, String password) throws Exception {
		// clickGmail();
          chooseEmail(email);
         // next();
          choosePassword(password);
        //  signIn();
	  }

	  private static void chooseEmail(String email)
      {
	    	 Global.getWriter().append("2- user Type User Name" +"\n");

	  utilites.SetProperites.waitElementPresent("identifierId", "id");
	    	  utilites.SetProperites.enterText("identifierId", email, "id");
	    	  utilites.SetProperites.waitElementClickable("//*[@jsname='Njthtb']", "xpath");
	    	  utilites.SetProperites.click("//*[@jsname='Njthtb']", "xpath");
	    	  utilites.SetProperites.waitElementNOTPresent("//*[@ARIA-BUSY=true]", "xpath");
	    }

	    private static void choosePassword(String password)
	      {
	    	 Global.getWriter().append("3- user Type Password" +"\n");

	    	  utilites.SetProperites.sleep(200);
	   utilites.SetProperites.waitElementPresent("password", "name");
	    	  utilites.SetProperites.clear("password", "name");
	    	  utilites.SetProperites.enterText("password", password, "name");
	    	  utilites.SetProperites.waitElementClickable("//*[@jsname='Njthtb']", "xpath");
	    	 try {
	    	  utilites.SetProperites.click("//*[@jsname='Njthtb']", "xpath");
	    	 }
	    	 catch(Exception e)
	    	 {
	    		 utilites.SetProperites.clickJS("//*[@jsname='Njthtb']", "xpath");
	    		
	    	 }
	    	 Global.getWriter().append("User Login Correctly" +"\n");

	    }

	   


}
