package utilites;

import static org.junit.Assert.fail;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SetProperites {

	 public static void enterText(String element, String value, String elementtype)
     {findElement(element,elementtype).sendKeys(value);
     }
	 public static String getText(String element, String elementtype)
     {return findElement(element,elementtype).getText();
     }
	 public static void sendKeys(String element,Keys key, String elementtype)
     {findElement(element,elementtype).sendKeys(key);
     }
     //click button
     public static void click(String element, String elementtype)
     {
    	 
    	 findElement(element,elementtype).click();
     }
     public static void click(WebElement element)
     {    	
    	 org.openqa.selenium.JavascriptExecutor js = ( org.openqa.selenium.JavascriptExecutor ) Global.getDriver( );
    		 js.executeScript("arguments[0].scrollIntoView()", element);
    	 element.click();
     }
     public static void clickJS(String element, String elementtype)
     {
     WebElement  ele=findElement(element,elementtype); 
     org.openqa.selenium.JavascriptExecutor js = ( org.openqa.selenium.JavascriptExecutor ) Global.getDriver( );
	 js.executeScript("arguments[0].click()", ele);
     }
     public static WebElement findElement(String element, String elementtype)
     {
    	
           return  Global.getDriver().findElement(element(element,elementtype));
		
     }
     public static List<WebElement> findElements(String element, String elementtype)
     {
    	
           return  Global.getDriver().findElements(element(element,elementtype));
		
     }
     public static By element(String element, String elementtype)
     {
    	 
    	 switch(elementtype) {
    	 case "id" :
         return By.id(element);
        case "name" : 
        	return By.name(element );
        case "xpath" : 
        	return  By.xpath(element );
        case "cssSelector" : 
        	return  By.cssSelector(element ) ;
        	case "className" : 
        	 return  By.className(element );
        case "linkText" : 
        	return  By.linkText(element )  ;
     }
		return null;
		
     }
   public static void waitElementPresent(String element,String elementtype)
   {
	   WebDriverWait wait = new WebDriverWait( Global.getDriver( ), 30);
	   wait.until(ExpectedConditions.visibilityOfElementLocated(element(element,elementtype)));
	   
	   
   }
   public static void waitElementNOTPresent(String element,String elementtype)
   {
	   WebDriverWait wait = new WebDriverWait( Global.getDriver( ), 10);
	   wait.until(ExpectedConditions.invisibilityOfElementLocated(element(element,elementtype)));
	   
	   
   }
   public static void waitElementClickable(String element,String elementtype)
   {
	   WebDriverWait wait = new WebDriverWait(Global.getDriver( ), 30);

	   wait.until(ExpectedConditions.elementToBeClickable(element(element,elementtype)));
   }
   public static void sleep(int time)
   {
	   try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
   
    public static void clear (String element, String elementtype)
    {
        if (elementtype == "id")
      Global.getDriver().findElement(By.id(element)).clear();
        else  if (elementtype == "name")
        Global.getDriver().findElement(By.name(element)).clear();
    }
   
    public static boolean isElementPresent(By by) {
	    try {
	    	Global.getDriver().findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }

	  public boolean isAlertPresent() {
	    try {
	    	Global.getDriver().switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }

	
}
 
