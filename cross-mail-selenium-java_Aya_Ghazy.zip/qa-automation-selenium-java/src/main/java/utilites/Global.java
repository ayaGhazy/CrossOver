package utilites;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Global {
	private static WebDriver driver ;
	private static 	PrintWriter writer ;
	
	public static PrintWriter getWriter()
	{
		if (writer == null)
		{
	
			try {
				writer= new PrintWriter("src/test/resources/Test Report.txt", "UTF-8");
			} catch (FileNotFoundException | UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
		return writer;
	}
	
	public static WebDriver getDriver()
	{
		if (driver == null)
		{
			driver = new ChromeDriver(); 
		}
		return driver;
	}
	

	
}
